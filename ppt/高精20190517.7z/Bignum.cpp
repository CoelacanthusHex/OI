#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxl=10005;
char a[maxl],b[maxl];
struct num
{
	//cun
	int a[maxl];
	
	//chuli
	num() { memset(a,0,sizeof(a));}
	num(char s[])
	{
		memset(a,0,sizeof(a));
		int len=strlen(s);
		for(int i=0;i<len;i++)
			a[++a[0]]=s[i]-'0';
		while(a[0]>0&&a[a[0]]==0)	a[0]--;
	}
	void print()
	{
		if(a[0]==0)
			cout<<0;
		else
			for(int i=a[0];i>0;i--)
				cout<<a[i];
		cout<<endl;
	}
	void add(int k)	{if(k||a[0]) a[++a[0]]=k;}
	void re(){reverse(a+1,a+a[0]+1);}
}p,q,ans;
bool operator <(const num &p,const num &q)
{
	if(p.a[0]!=q.a[0])	return p.a[0]<q.a[0];
	for(int i=p.a[0];i>0;i--)
		if(p.a[i]!=q.a[i])
			return p.a[i]<q.a[i];
	return false;
}
num operator +(const num &p,const num &q)
{
	num c;
	c.a[0]=max(p.a[0],q.a[0]);
	for(int i=1;i<=c.a[0];i++)
	{
		c.a[i]+=p.a[i]+q.a[i];
		c.a[i+1]=c.a[i]/10;
		c.a[i]%=10;
	}
	if(c.a[c.a[0]+1]) c.a[0]++;
	
	return c;
}
num operator -(const num &p,const num &q)
{
	num c=p;
	for(int i=1;i<=c.a[0];i++)
	{
		c.a[i]-=q.a[i];
		if(c.a[i]<0)
			c.a[i]+=10,c.a[i+1]--;
	}
	while(c.a[0]>0&&c.a[c.a[0]]==0) c.a[0]--;
	
	return c;
}
num operator *(const num &p,const num &q)
{
	num c;
	c.a[0]=p.a[0]+q.a[0]-1;
	for(int i=1;i<=p.a[0];i++)
	for(int j=1;j<=q.a[0];j++)
	{
		c.a[i+j-1]+=p.a[i]*q.a[i];
		c.a[i+j]+=c.a[i+j-1]/10;
		c.a[i+j-1]%=10;
	}
	if(c.a[c.a[0]+1]) c.a[0]++;
	
	return c;
}
//num operator /(const num &p,const num &q)
//{
//	num x,y;
//	for(int i=p.a[0];i>0;i--)
//	{
//		y.add(p.a[i]);
//		y.re();
//		while(!(y<q))
//			y=y-q,x.a[i]++;
//		y.re();
//	}
//	x.a[0]=p.a[0];
//	while(x.a[0]>0&&x.a[x.a[0]]==0) x.a[0]--;
//	
//	return x;
//}
num div(const num &p,const num &q,int k)
{
	num x[2];
	for(int i=p.a[0];i>0;i--)
	{
		x[1].add(p.a[i]);
		x[1].re();
		while(!(x[1]<q))
			x[1]=x[1]-q,x[0].a[i]++;
		x[1].re();
	}
	x[0].a[0]=p.a[0];
	while(x[0].a[0]>0&&x[0].a[x[0].a[0]]==0) x[0].a[0]--;
	
	return x[k];
}
int main()
{
	cin>>a>>b;
	reverse(a,a+strlen(a));
	reverse(b,b+strlen(b));
	
	p=num(a);q=num(b);
	
	ans=p+q;
	ans.print();
	
	ans=p-q;
	ans.print();
	
	ans=p*q;
	ans.print();
	
//	ans=p/q;
//	ans.print();
	ans=div(p,q,0);
	ans.print();
	ans=div(p,q,1);
	ans.print();	
	
	
	return 0;
}
