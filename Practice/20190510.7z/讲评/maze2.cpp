#include<cstdio>
#define rep(i,s,t) for(int i=s;i<=n;i++)
#define x first
#define y second
using namespace std;
char map[2333][2333];
pair <int,int> chara[233];
int pot(int x,int y)
{
	return (i-1)*m+j;
}
int main()
{
	freopen("in.txt","r",stdin);
	scanf("%d%d",&n,&m);
	rep(i,1,n)
		rep(j,1,m)
		{
			cin>>ci;
			map[i][j]=ci;
			if(ci=='=')
				start=pot(i,j);
			if(ci=='@')
				end=pot(i,j);
			if(ci>='A'&&ci<='Z')
			{
				chara[ci-'A'].x=i;
				chara[ci-'A'].y=j;
			}
		}
	rep(i,1,n)
		rep(j,1,n)
		{
			char ci=map[i][j];
			if(ci!='#'&&(ci<'A'||ci>'Z'))
			{
				if(mmp[i+1][j]!='#'&&(mmp[i+1][j]<'A'||mmp[i+1][j]>'Z'))
				{
					int u=pot(i,j);
					int v=pot(i+1,j);
					add(u,v,1);
					add(v,u,1);
				}
				if(mmp[i][j+1])
				
			}
			if(ci>='A'&&ci<='Z')
			{
				if(mmp[i-1][j]!='#')
				{
					int p1=(i,j);
					int p2=(i-1,j);
					int p3=(chara[ci-'A'].x,chara[ci-'A'].y);
					add(p1,p3,1);
					add(p2,p1,1);
				}
				if(i+1,j
					i,j-1
					i,j+1
			}
			
			
		}
	return 0;
}


���ȴ�����
 
