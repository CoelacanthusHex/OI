#include <iostream>
using namespace std;
const int maxn=100005;
int dq[maxn],n,head=0,tail=1,t,cnt; 
char c;
int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>c;
		if(c == 'A')
		{
			cin>>c;
			if(c == 'L')
				dq[head]=++cnt,head=(head-1+maxn)%maxn;
			if(c == 'R')
				dq[tail]=++cnt,tail=(tail+1)%maxn;
		}
		else
		{
			cin>>c>>t;
			if(c == 'L')
				head=(head+t)%maxn;	
			if(c == 'R')
				tail=(tail-t+maxn)%maxn;
		}
			}
	for(int i=head+1;i%maxn!=tail%maxn;i++)
		cout<<dq[i%maxn]<<endl;
	return 0;
}
