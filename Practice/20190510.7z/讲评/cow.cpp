#include <iostream>
#include <deque>
#include <cstdio>
#include <algorithm>
using namespace std;
int main()
{
	freopen("cow.in" , "r" , stdin);
	freopen("cow.out" , "w" , stdout);
	int t , x = 0 , opt;
	deque<int> q;
	char c;
	scanf("%d" , &t);
	getchar();
	while(t--)
	{
		c = getchar();
		getchar();
		if(c == 'A')
		{
			c = getchar();
			if(c == 'L')
				q.push_front(++x);
			if(c == 'R')
				q.push_back(++x);
		}
		if(c == 'D')
		{
			c = getchar();
			getchar();
			scanf("%d" , &opt);
			if(c == 'L')
				for(int i = 1; i <= opt; i++)
					q.pop_front();	
			if(c == 'R')
				for(int i = 1; i <= opt; i++)
					q.pop_back();
		}
		getchar();
	}
	for(int i = 0; i < q.size(); i++)
		printf("%d\n" , q[i]);
	return 0;
}
