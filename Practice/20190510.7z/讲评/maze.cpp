#include <cstdio>
#include <iostream>
#include <cstring>
#include <queue>
using namespace std;
const int maxn = 505;
const int next_x[4] = {0 , 0 , 1 , -1};
const int next_y[4] = {1 , -1 , 0 , 0};
int n , m;
struct node
{
	int x , y;
}maze[30][2];
struct node1
{
	int x , y , dis;
};
node1 start;
char a[maxn][maxn];
int used[maxn][maxn];
queue<node1> q;
int main()
{
	freopen("maze.in" , "r" , stdin);
	freopen("maze.out" , "w" , stdout);
	cin >> n >> m;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
		{
			cin >> a[i][j];
			if(a[i][j] >= 'A' && a[i][j] <= 'Z')
			{
				int tmp = a[i][j] - 'A';
				if(!maze[tmp][0].x && !maze[tmp][0].y)
					maze[tmp][0].x = i , maze[tmp][0].y = j;
				else
					maze[tmp][1].x = i , maze[tmp][1].y = j;
			}
			if(a[i][j] == '@')
				start.x = i , start.y = j;
		}
	used[start.x][start.y] = 1;
	node1 tmp = (node1){start.x , start.y , 0};
	q.push(tmp);
	while(!q.empty())
	{
		node1 now = q.front();	
		q.pop();
		for(int i = 0; i < 4; i++)
		{
			tmp = now;
			tmp.x += next_x[i];
			tmp.y += next_y[i];
			tmp.dis++;
			if(tmp.x < 0 || tmp.y < 0)
				continue;
			if(a[tmp.x][tmp.y] == '=')
			{
				cout << tmp.dis;
				return 0;
			}
			if(a[tmp.x][tmp.y] == '#')
				continue;
			if(a[tmp.x][tmp.y] >= 'A' && a[tmp.x][tmp.y] <= 'Z')
			{
				int tmp_1 = a[tmp.x][tmp.y] - 'A';
				if(maze[tmp_1][0].x == tmp.x && maze[tmp_1][0].y == tmp.y)
					tmp.x = maze[tmp_1][1].x , tmp.y = maze[tmp_1][1].y;
				else
					tmp.x = maze[tmp_1][0].x , tmp.y = maze[tmp_1][0].y;
			}
			if(used[tmp.x][tmp.y])
				continue;
			used[tmp.x][tmp.y] = 1;
			q.push(tmp);
		}
	}
	return 0;
}
