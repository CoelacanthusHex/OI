#include <cstdio>
#include <iostream>
using namespace std;
const int N = 405;
int a[N][N];
int n , m , v;
long long ans;
int read()
{
	int x = 0 , fx = 1;
	char ch = getchar();
	while(ch > '9' || ch < '0')
	{
		if(ch == '-')
			fx = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9')
	{
		x = (x << 3) + (x << 1) + (ch & 15);
		ch = getchar();
	}
	return x * fx;
}
inline bool check(int x)
{
	long long w = 0;
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
			if(a[i][j] < x)
				w += x - a[i][j];
	return w >= v;
}
int main()
{
	freopen("flood.in" , "r" , stdin);
	freopen("flood.out" , "w" , stdout);
	n = read() , m = read() , v = read();
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
			a[i][j] = read();
	int l = 1 , r = v , mid;
	while(l < r)
	{
		mid = (l + r) >> 1;
		if(check(mid))
			r = mid;
		else
			l = mid + 1;
	}
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++)
			if(a[i][j] <= r)
				ans += a[i][j];
	cout << r << ' ' << ans << endl;
	return 0;
}
